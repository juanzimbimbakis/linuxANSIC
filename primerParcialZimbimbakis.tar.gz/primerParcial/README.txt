------------

Un partidazo.

Pasos para jugar el partido: 

- Abrir 3 terminales.

- En la primera ejecutar "./pEquipo 1 3" el segundo parametro enviado es la cantidad de goles a que se juega el partido. Se puede jugar de 1 a 3 goles. Tambien podria ser "./pEquipo 1 2" si se quisiera jugar a 2 goles. el parametro "1" indica que se esta ejecutando el equipo 1.

- En la segunda terminal ejecutar "./pEquipo 2 3" IMPORTANTE: los goles deben coincidir en ambas ejecuciones. El parametro "2" indica que se esta ejecutando el equipo 2.

- En la tercer terminal ejecutar "./pPanel"

Luego debe ingresar un numero del 1 al 3 para el equipo 1, luego lo mismo para el equipo 2 y se actualizara en la terminal del Panel el resultado del partido. 

PUEDE HABER EMPATE. 

Una vez finalizado el partido termina el proceso pPanel.

------------ 
