#ifndef _memoria_h
#define _memoria_h


void* creo_memoria(int size, int* r_id_memoria, int clave_base);


#endif
