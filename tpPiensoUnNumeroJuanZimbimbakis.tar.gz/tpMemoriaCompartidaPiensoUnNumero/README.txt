

Programa de pienso un  numero: 

Abrir dos terminales, en la primera ejecutar pPienso. En la segunda ejecutar pJugador e ingresar nombre del jugador. 

Cuando se acierte el numero, termina el programa con el nombre del ganador y la cantidad de intentos en otra terminal.


