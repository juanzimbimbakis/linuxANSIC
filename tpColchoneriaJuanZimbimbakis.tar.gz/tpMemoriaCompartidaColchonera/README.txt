

----------

Ejercicio de colchoneria:

- abrir dos terminales

- en la primera ejecutar pColchoneria

- en la segunda ejecutar pVendedor

(primero pColchoneria)

- ingresar desde el vendedor el codigo de colchon a vender y luego las unidades. Si hay stock se resta, sino hay mensaje de stock insuficiente

Terminar los programas con control c

Aclaracion: (En clase preguntare de usar una bandera para terminar ambos programas y asi que se borre la memoria compartida)


----------


