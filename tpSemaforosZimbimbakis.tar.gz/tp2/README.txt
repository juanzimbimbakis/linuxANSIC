README Ejercicio reserva de vuelos:

Abrir 2 terminales.

Primero ejecutar "./pCarga"

Segundo Ejecutar "./pReserva"

Nos pregunta el destino, luego nombre de pasajero. Una vez ingresados nos los muestra ya procesados y camabiado el nombre del archivo.

IMPORTANTE: 

- Ingresar el nombre del destino sin espacios, ya sea camelCase o con "_" en el espacio.
- El nombre del pasajero se puede ingresar con espacios.
- La cantidad de ingresos por lote es de 2 para no hacerlo extenso y poder probarlo, se podria hacer mas ingresos si se lo requiere.


README Ejercicio Banco:


Abrir 4 terminales. Se ejecutan los programas pCajero y pTesorero. 

Primero se ejecuta "./pCajero 1" (esencial que este sea el primero), es importante pasarle el parametro 1, 2 o 3 para ejecutar el cajero que se quiere. Si no se ponen parametros o no se mandan entre 1 y 3, termina el programa con return 1.

Segundo se ejecuta "./pCajero 2"

Tercero "./pCajero 3"

Cuarto "./pTesorero"

Nos pregunta la cantidad de depositos a realizar, luego el monto del deposito y luego si es cheque o efectivo. A continuacion nos muestra los depositos de cajero 1, 
cajero 2, cajero 3 y la sumatoria de estos 3. 
