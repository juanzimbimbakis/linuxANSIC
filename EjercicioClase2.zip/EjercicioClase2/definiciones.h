#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H

#define TRUE 1
#define FALSE 0
#define DESDE 0
#define HASTA 50

#endif
