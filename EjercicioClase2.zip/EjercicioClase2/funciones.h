#ifndef _FUNCIONES_H
#define _FUNCIONES_H


int inDevolverNumeroAleatorio(int desde, int hasta);

int inDevolverNumeroAleatorioNoRepetitivo(int desde, int hasta);

int validarRepetido(int numero);

#endif
