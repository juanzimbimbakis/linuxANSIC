#ifndef _FUNCIONES_H
#define _FUNCIONES_H

int devolverNumeroAleatorio(int minimo, int maximo);


#endif

