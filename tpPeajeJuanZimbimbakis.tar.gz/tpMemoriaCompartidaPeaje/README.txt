
---------------

Programa Peaje:

- Abrir 2 terminales

- En la primer terminal ejecutar pP pasandole como unico parametro la cantidad de vias

- En la segunda terminal ejecutar pA pasandole como unico parametro la cantidad de vias (tiene que coincidir con el numero del primer programa)


ACLARACION: aprox. a los 15'' de su ejecucion terminan los programas oara que se pueda borrar la memoria compartida.

--------------

